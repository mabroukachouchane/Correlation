import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;


public class test {
static int NC=0;
static int PDIST=0;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		 InputStream myxls = new FileInputStream("/Users/bessghaiernarjess/Documents/Research-Collaboration/Mabrouka/Change-frequency/equations-java.xls");
      
		 HSSFWorkbook wb     = new HSSFWorkbook(myxls);
		 
		 HSSFSheet sheet = wb.getSheetAt(0);// first sheet
		    
		 // calculate number of columns per row
		 //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// int NB= Columns();
         
            //  Row headerRow = (Row) rowIterator.next();
              //get the number of cells in the header row
        	  HSSFRow row     = sheet.getRow(0);        // first row
              int noOfColumns = sheet.getRow(0).getLastCellNum();
              //System.out.println(noOfColumns);
         // calcul NC     
        for (int c=1;c<noOfColumns; c++)
        {
        	HSSFCell cell= row.getCell(c);
        	cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
        	 NC=NC+ (int)Math.round(cell.getNumericCellValue());
        	  //System.out.println((int)Math.round(cell.getNumericCellValue()));
       	 
        }
        // calcul PDIST
        for (int c=2;c<noOfColumns; c++)
        {
        	HSSFCell cell1= row.getCell(c-1);
        	HSSFCell cell= row.getCell(c);
        	cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
        	 PDIST=PDIST+ (int)Math.round(cell.getNumericCellValue())-(int)Math.round(cell1.getNumericCellValue());
        	  //System.out.println((int)Math.round(cell.getNumericCellValue()));
       	 
        }
        
        int CF= (NC/(PDIST*100));
        System.out.println(NC);
        System.out.println(PDIST);
        System.out.println(CF); 
		
			
	}



}
