import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import jxl.Cell;
import jxl.CellType;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CF {

	static int NC=0;
	static double PDIST=0;
	//static double total=0;
		public static void main(String[] args) throws IOException {
			// TODO Auto-generated method stub
			
			 InputStream myxls = new FileInputStream("/Users/bessghaiernarjess/Documents/Research-Collaboration/Mabrouka/Change-frequency/equations-java.xls");
	      
			 HSSFWorkbook wb     = new HSSFWorkbook(myxls);
			 
			 HSSFSheet sheet = wb.getSheetAt(0);
			    
			 // calculate number of columns per row
			 //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			// int NB= Columns();
	         
	            //  Row headerRow = (Row) rowIterator.next();
	              //get the number of cells in the header row
			 //HSSFRow row     = sheet.getRow(0);        
             //int noOfColumns = sheet.getRow(0).getLastCellNum();
	           //   System.out.println("columns"+noOfColumns);
	         // calcul NC  
	              // get number of rows
	              
	             int rowTotal = sheet.getLastRowNum();

	              if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	                  rowTotal++;
	              } 
	              //System.out.println(rowTotal);
	              
	         for ( int r=0;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r);        
             int noOfColumns = sheet.getRow(r).getLastCellNum();
            // System.out.println("r="+(r+1)+"has"+noOfColumns);
             //NC
	        for (int c=1;c<noOfColumns; c++)
	        
	        {
	  
	        	HSSFCell cell= row.getCell(c);
	        	cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	        	 NC=NC+ (int)(cell.getNumericCellValue());
	        	  //System.out.println((int)Math.round(cell.getNumericCellValue()));
	        	//System.out.println(NC);
	        	 //PDIST
	        }
	        for (int i=noOfColumns-1;i>1;i-- ){
	        	 HSSFCell cell1= row.getCell(i);
	 	        	HSSFCell cell2= row.getCell(i-1);
	 	        	cell1.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	 	        	cell2.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	 	        	 
		 	     PDIST=PDIST+(double)(cell1.getNumericCellValue())-(double)(cell2.getNumericCellValue());
		 	        	//  System.out.println(PDIST);
		 	    
	        }
	      
	        	
	 	        System.out.println("NC="+NC);
	 	        System.out.println("PDIST="+PDIST);
	 	        double CF= (NC/(PDIST*100));
	 	        System.out.println("CF App"+(r+1)+"="+CF);  
	 	       System.out.println("#########################");  
	        NC= 0;
	        PDIST=0;
	        
	         }        
	      /*   for ( int r=0;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r);        
	             int noOfColumns = sheet.getRow(r).getLastCellNum();
	             System.out.println("r="+r+"has"+noOfColumns);
	             
	             
	         //PDIST
	             
	             
		        for ( int i=noOfColumns-1;i>1; i--)
		 	        {
		        	HSSFCell cell1= row.getCell(i);
	 	        	HSSFCell cell2= row.getCell(i-1);
	 	        	cell1.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	 	        	cell2.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	 	        	 
		 	        			 PDIST=PDIST+( (double)(cell1.getNumericCellValue())-(double)(cell2.getNumericCellValue()));
		 	        	  System.out.println(PDIST);
		 	       	 
		 	        }  
		        //System.out.println("NC="+NC);
	 	        System.out.println("PDIST="+PDIST);
	 	        //double CF= (NC/(PDIST*100));
	 	        //System.out.println("CF App"+(r+1)+"="+CF);  
	       // NC= 0;
	        PDIST=0;
			
				
		}*/

		}

	}
